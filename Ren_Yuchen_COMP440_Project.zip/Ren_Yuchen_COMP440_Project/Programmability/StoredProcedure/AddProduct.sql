USE [s16guest21]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure [dbo].[add_product]
(@product_id int,@product_Name char(255),@company_id int)
as
begin try

insert into Product
(Product_id,Product_Name,Company_id)
values (@product_id,@product_Name,@company_id)

End try 

begin catch
declare @ErrorMessage nvarchar(4000)
declare @ErrorSeverty INT
declare @ErrorState INT
select @ErrorMessage = ERROR_MESSAGE(),
       @ErrorSeverty = ERROR_SEVERITY(),
	   @ErrorState = ERROR_STATE()

	   Raiserror (@ErrorMessage,@ErrorSeverty,@ErrorState);
end catch

GO

