USE [s16guest21]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Update_Version] 
    @Product_Name varchar(255), 
	@Version varchar(16),
	@New_Version varchar(16) 
AS

BEGIN

	SET NOCOUNT ON;
	DECLARE @This_Product_Id int
	DECLARE @This_Version_Id int
	

	SELECT @This_Product_Id = Product_Id FROM Product WHERE Product_Name = @Product_Name;
	IF (@@ROWCOUNT < 1)
	BEGIN
		PRINT 'Product does not exist.'
		RETURN
	END


	SELECT @This_Version_Id = Version_Id FROM Version WHERE Product_Id = @This_Product_Id AND Version_Label = @Version;
	IF (@@ROWCOUNT < 1)
	BEGIN
		PRINT 'Version does not exist.'
		RETURN
	END


	UPDATE version
	SET Version_Label = @New_Version
	WHERE Product_Id = @This_Product_Id AND Version_Id = @This_Version_Id;

	END

GO


EXEC Update_Version     
	@Product_Name = 'EHR System' , 
	@Version = '1.1',
	@New_Version = '1.7'