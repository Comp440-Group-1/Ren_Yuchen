USE [s16guest21]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Go
create procedure [dbo].[new_features]
    @Product_Name varchar(255),
	@Version_Label varchar(255)
as
begin try

select feature_name from feature inner join version on feature.version_ID = version.Version_ID inner join development_release on development_release.Release_ID = feature.release_id inner join product on product.Product_ID = version.Product_ID
where (Version_Label = @Version_Label and product_name = @Product_Name and Release_type != 'bug-fix release')

End try 

begin catch
declare @ErrorMessage nvarchar(4000)
declare @ErrorSeverty INT
declare @ErrorState INT
select @ErrorMessage = ERROR_MESSAGE(),
       @ErrorSeverty = ERROR_SEVERITY(),
	   @ErrorState = ERROR_STATE()

	   Raiserror (@ErrorMessage,@ErrorSeverty,@ErrorState);
end catch

Go


EXEC new_features   
'EHR System' , '2.2'