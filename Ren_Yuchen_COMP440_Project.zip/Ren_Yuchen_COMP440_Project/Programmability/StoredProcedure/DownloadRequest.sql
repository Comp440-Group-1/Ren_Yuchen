USE [s16guest21]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
alter procedure download
(@version_id int,@year int)
as
begin try
declare @i int
declare @j varchar(50)
set @i = 1
while @i< 12
begin
select @j= count(*) from download_record where (month(convert(datetime,download_date))= @i) and Version_ID = @version_id and (year(convert(datetime,download_date))= @year)

print 'the download time for month '+convert(varchar, @i)+' is '+@j

set @i = @i+1

end
End try 

begin catch
declare @ErrorMessage nvarchar(4000)
declare @ErrorSeverty INT
declare @ErrorState INT
select @ErrorMessage = ERROR_MESSAGE(),
       @ErrorSeverty = ERROR_SEVERITY(),
	   @ErrorState = ERROR_STATE()

	   Raiserror (@ErrorMessage,@ErrorSeverty,@ErrorState);
end catch

GO

EXEC download '1','2000'